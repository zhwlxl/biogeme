//
//  OtherLibDyn.hpp
//  OtherLibDyn
//
//  Created by Nikola Obrenovic on 18.10.17.
//  Copyright © 2017 Nikola Obrenovic. All rights reserved.
//

#ifndef OtherLibDyn_h
#define OtherLibDyn_h

#include <stdio.h>

extern "C" int MakeNumDyn();

#endif /* OtherLibDyn_hpp */
