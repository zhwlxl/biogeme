//
//  OtherLibDyn.cpp
//  OtherLibDyn
//
//  Created by Nikola Obrenovic on 18.10.17.
//  Copyright © 2017 Nikola Obrenovic. All rights reserved.
//

#include "OtherLibDyn.h"

extern "C" int MakeNumDyn()
{
    return 777;
}
